# HealthIQ AI — Android phone-first health insights (v0.1.0)

Native Kotlin / Jetpack Compose Android Studio project. **No watch, wearable, external device, server, subscription, or login required.**

## What's implemented

- **Today**: phone-recorded steps, walking distance, most recent sleep and weight; confidence-aware insight cards.
- **Trends**: step count, recorded sleep, body weight and waist charts.
- **Body**: dated manual MeThreeSixty measurement logging — waist/stomach, chest, hips, neck, thigh, upper arm and optional weight; edit/delete.
- **Journal**: mood, energy and stress ratings; fasting hours, sleep, hydration and notes; edit/delete.
- **Health Connect**: user-consented step counts, distance, active calories, recorded exercise, sleep and weight. Automatic foreground sync on app opening, plus periodic WorkManager sync (every ~6 h, subject to Android scheduling and background-read permission). Aggregates steps to avoid counting duplicate sources twice.
- **Weight Trend CSV import**: compatible with the `#WeightTrendBackup: 1` v6 semicolon CSV format and simple `date,weight` CSV. The imported weight history is independent of the body-scan log.
- **CSV backup export**: local file picker lets the user save their data.
- **Analytics**: explicit, on-device rules; requires sufficient measurements before claiming a trend. Does not label absent data as zero.

## Important limitations

**This is a source project, not a tested APK.** The build environment used to assemble these files has no installed Android SDK and cannot download one. The code has been reviewed but **has not been compiled or run on a phone**. The provided GitHub Actions workflow lets you compile a debug APK in a repository you control.

"AI" in this first version means data-driven **local trend analysis**, not a large-language-model chatbot, predictive medical system, or medical diagnosis. No data ever goes to OpenAI or any other service. You can extend it with optional local or self-hosted models later.

MeThreeSixty's official FAQ explicitly says it does not currently offer built-in export of its stored 3D scan data, and no supported API integration has been identified. Therefore **no direct automatic MeThreeSixty sync**; enter its displayed measurements manually. The application does not access other apps' private databases, scrape login tokens or reverse-engineer its service.

Health Connect can provide steps measured by the phone itself on **supported Android 14+ systems with SDK extension 20+** when `READ_STEPS` is authorized. Otherwise, step counts must already be written to Health Connect by a supported phone app. Sleep, weight, calories and exercise are shown only if another phone app or manual source recorded them; a phone alone does not automatically measure all these things. Background reading is optional and requires additional permission; WorkManager is not an exact-time scheduler.

Local data is in the app's private SQLite database, **not separately encrypted**. Cloud and device-transfer automatic backups are disabled for the sensitive database: use CSV export and store the export securely. Uninstalling can remove your history.

## Build an Android APK

### Option A — Android Studio on Debian/Windows/macOS

1. Install Android Studio (with Android SDK Platform 35 and build tools).
2. Open this directory **`HealthIQ-Android/`** in Android Studio.
3. Allow the project to sync Gradle and install missing dependencies; use JDK 17.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)** (or use `./gradlew assembleDebug`).
5. Find your APK at **`app/build/outputs/apk/debug/app-debug.apk`**. Copy and install it on your Android phone. You may need to allow installing apps from your file manager.

The `gradlew` script downloads Gradle 8.11.1 if a system Gradle is not installed (a standard wrapper JAR is not bundled).

### Option B — GitHub Actions (build in a private repository)

1. Create a private GitHub repository.
2. Upload these project files, including `.github/workflows/android.yml`.
3. In the repository's **Actions** tab, select **Build Android debug APK → Run workflow**.
4. Download the `HealthIQ-debug-APK` build artifact when the build succeeds. Extract it to get `app-debug.apk`.

Only source code needs to be uploaded to GitHub; **never commit exported health CSV records**.

### First run

1. Launch **HealthIQ AI**.
2. Under **Settings → Manage Health Connect access**, grant access to the specific types of health data you want read.
3. If available, permit **Read health data in the background** for automatic syncing while the app isn't open.
4. Return to the home tab. A sync occurs automatically when you open the app, without requiring you to tap Refresh.
5. Use **Settings → Import weight CSV** if you want to bring in Weight Trend history, and **Body** to log MeThreeSixty scan measurements.
6. Use **Settings → Export CSV backup** to save a copy before uninstalling or changing phones.

## Design / code organization

| File | Purpose |
| --- | --- |
| `MainActivity.kt` | Material 3 interface, screens, dialogs, app state and import/export |
| `HealthSync.kt` | Health Connect permissions, aggregation, historical reads and worker |
| `Store.kt` | Private SQLite records and CSV export |
| `CsvImport.kt` | Weight Trend and generic CSV parser |
| `Insights.kt` | Transparent on-device trend calculations |
| `CsvImportTest.kt` | Import parsing unit tests |

### Privacy

No `INTERNET` permission is declared. Android's `ACTION_VIEW_PERMISSION_USAGE` Health Connect disclosure screen is implemented. Health Connect permissions are opt-in and may be revoked at any time.

### Known next steps

- Test an actual install on Samsung Android 16, including Health Connect background/history permission availability and phone-generated step count.
- Add integration tests and confirm release build behavior.
- Add user-defined goals, charts with calendar x-axis, and optional screenshot OCR-assisted MeThreeSixty entry (with the user's permission).
- If desired, add a separately permissioned, transparent AI chatbot mode **only after** choosing a trusted on-device model or a user-controlled backend.
