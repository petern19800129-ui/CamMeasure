@echo off
setlocal
if not "%GRADLE_HOME%"=="" (
  call "%GRADLE_HOME%\bin\gradle.bat" %*
  exit /b %ERRORLEVEL%
)
set DIST=%USERPROFILE%\.gradle\healthiq-bootstrap\gradle-8.11.1
if not exist "%DIST%\bin\gradle.bat" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Join-Path $env:USERPROFILE '.gradle\healthiq-bootstrap'; New-Item -Force -ItemType Directory $d | Out-Null; $z=Join-Path $d 'gradle-8.11.1-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $z; Expand-Archive -Force -Path $z -DestinationPath $d"
)
call "%DIST%\bin\gradle.bat" %*
