package za.co.healthiq

import org.junit.Assert.assertEquals
import org.junit.Test

class CsvImportTest {
    @Test fun readsWeightTrendExport() {
        val text="""
            #Version: 6
            #Units: kg
            #WeightTrendBackup: 1
            #date;weight;weight trend;body fat;body fat trend;muscle mass;muscle mass trend;log
            2026-09-30T05:49:44.718114Z;65.3;65.4;;;;;
            2026-10-01T05:48:57.977958Z;65.2;65.3;;;;;
        """.trimIndent()
        assertEquals(listOf("2026-09-30" to 65.3,"2026-10-01" to 65.2),CsvImport.weights(text))
    }
    @Test fun mergesSameDayMeasurements() {
        val csv="""date,weight
            2026-09-30,65.3
            2026-09-30,65.1""".trimIndent()
        assertEquals(listOf("2026-09-30" to 65.1),CsvImport.weights(csv))
    }
    @Test fun noInvalidWeights() {
        assertEquals(emptyList<Pair<String,Double>>(),CsvImport.weights("date,weight\n2026-09-30,999"))
    }
    @Test fun readsMeThreeSixtyMetricsAndOneDatedScan() {
        val text="""date,metric,value,unit,source
            2026-10-14,waist,80.0,cm,Example
            2026-10-14,left_bicep,25.0,cm,Example
            2026-10-14,right_bicep,26.0,cm,Example
            2026-10-14,weight,60.0,kg,Example""".trimIndent()
        val b=CsvImport.read(text)
        assertEquals(4,b.metrics.size)
        assertEquals(1,b.bodies.size)
        assertEquals(80.0,b.bodies.first().waist!!,0.001)
        assertEquals(null,b.bodies.first().arm)
    }
    @Test fun readsOldHealthIqBackup() {
        val columns="type,date,steps,distance_m,active_kcal,sleep_minutes,weight_kg,exercise_minutes,waist_cm,chest_cm,hips_cm,neck_cm,thigh_cm,arm_cm,mood,energy,stress,fasting_hours,sleep_hours,water_litres,source,notes".split(",")
        val row=columns.map{ col -> when(col){
            "type"->"body";"date"->"2026-10-14";"weight_kg"->"60.0";"waist_cm"->"80.0";"chest_cm"->"90.0";"source"->"Example";else->""
        } }
        val b=CsvImport.read(columns.joinToString(",")+"\n"+row.joinToString(","))
        assertEquals(1,b.bodies.size)
        assertEquals(80.0,b.bodies.first().waist!!,0.001)
    }
}
