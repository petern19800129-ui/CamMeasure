package za.co.healthiq

import org.junit.Assert.assertEquals
import org.junit.Test

class CsvImportTest {
    @Test fun readsWeightTrendExport() {
        val text="""
            #Version: 6
            #Units: kg
            #WeightTrendBackup: 1
            #date;weight;weight trend;body fat;body fat trend;muscle mass;muscle mass trend;log
            2026-09-30T05:49:44.718114Z;65.3;65.4;;;;;
            2026-10-01T05:48:57.977958Z;65.2;65.3;;;;;
        """.trimIndent()
        assertEquals(listOf("2026-09-30" to 65.3,"2026-10-01" to 65.2),CsvImport.weights(text))
    }
    @Test fun mergesSameDayMeasurements() {
        val csv="""date,weight
            2026-09-30,65.3
            2026-09-30,65.1""".trimIndent()
        assertEquals(listOf("2026-09-30" to 65.1),CsvImport.weights(csv))
    }
    @Test fun noInvalidWeights() {
        assertEquals(emptyList<Pair<String,Double>>(),CsvImport.weights("date,weight\n2026-09-30,999"))
    }
}
