package za.co.healthiq

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.health.connect.client.PermissionController
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Ink=Color(0xFF152440)
private val Subtle=Color(0xFF69798E)
private val Mint=Color(0xFF078C83)
private val CanvasBg=Color(0xFFF5F7FA)
private val Line=Color(0xFFE8EDF3)
private val Sky=Color(0xFF4C83F0)

class MainActivity:ComponentActivity() {
    private val model by lazy { AppModel(this) }
    private val permissions = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) {
        HealthSync.schedule(this)
        lifecycleScope.launch { model.sync() }
    }
    private val csvImport = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri:Uri? ->
        if(uri!=null) lifecycleScope.launch {
            try {
                val content=withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: "" }
                val details=withContext(Dispatchers.IO) { importData(content) }
                model.reload("Imported $details")
            } catch (e:Exception) { model.message("Import failed: ${e.message}") }
        }
    }
    private val csvExport = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri:Uri? ->
        if(uri!=null) lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(Store(this@MainActivity).use{db->db.exportCsv()})} }
                model.message("CSV backup saved")
            } catch(e:Exception) { model.message("Export failed: ${e.message}") }
        }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        HealthSync.schedule(this)
        setContent {
            HealthTheme {
                if(intent?.action == Intent.ACTION_VIEW_PERMISSION_USAGE) {
                    PrivacyScreen()
                } else {
                    HealthApp(
                        state=model.state,
                        onGrant={
                            if(HealthSync.available(this)) permissions.launch(HealthSync.requestPermissions(this))
                            else model.message("Health Connect is unavailable on this device")
                        },
                        onSync={lifecycleScope.launch { model.sync() }},
                        onBody={v->lifecycleScope.launch{model.saveBody(v)}},
                        onDeleteBody={v->lifecycleScope.launch{model.deleteBody(v)}},
                        onJournal={v->lifecycleScope.launch{model.saveJournal(v)}},
                        onDeleteJournal={v->lifecycleScope.launch{model.deleteJournal(v)}},
                        onImport={csvImport.launch(arrayOf("text/*", "application/csv", "application/octet-stream"))},
                        onExport={csvExport.launch("HealthIQ-backup-${LocalDate.now()}.csv")}
                    )
                }
            }
        }
        lifecycleScope.launch { model.reload(); model.sync() }
    }
    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { model.sync() }
    }

    private fun importData(content:String):String {
        val batch=CsvImport.read(content)
        Store(this).use { db ->
            batch.days.forEach { db.putDaily(it) }
            batch.journals.forEach { db.putJournal(it) }
            batch.bodies.forEach { db.mergeImportedBody(it) }
            batch.metrics.forEach { db.putMetric(it) }
            batch.weights.forEach { (date,kg)-> db.mergeBodyWeight(date,kg) }
        }
        return listOfNotNull(
            batch.metrics.size.takeIf{it>0}?.let{"$it body metrics"},
            batch.bodies.size.takeIf{it>0}?.let{"$it body scan(s)"},
            batch.weights.size.takeIf{it>0}?.let{"$it weights"},
            batch.days.size.takeIf{it>0}?.let{"$it health days"},
            batch.journals.size.takeIf{it>0}?.let{"$it journal entries"}
        ).joinToString(" • ")
    }

}

data class UiState(
    val days:List<Daily> = emptyList(), val bodies:List<Body> = emptyList(), val bodyMetrics:List<BodyMetric> = emptyList(),
    val journals:List<Journal> = emptyList(), val weights:List<WeightEntry> = emptyList(), val status:String="Loading phone data…",
    val syncActive:Boolean=false, val hcAvailable:Boolean=false,
    val permissionsGranted:Int=0, val backgroundAllowed:Boolean=false,
    val lastSync:String="Never"
)

class AppModel(private val activity:ComponentActivity) {
    var state by mutableStateOf(UiState())
        private set
    private val app get()=activity.applicationContext
    private var syncing=false

    suspend fun reload(overrideStatus:String?=null) {
        val records=withContext(Dispatchers.IO) { Store(app).use { db ->
            UiState(days=db.allDaily(),bodies=db.allBody(),bodyMetrics=db.allMetrics(),journals=db.allJournal(),weights=db.allWeights())
        } }
        state=state.copy(days=records.days,bodies=records.bodies,bodyMetrics=records.bodyMetrics,journals=records.journals,
            weights=records.weights,status=overrideStatus?:state.status)
    }
    fun message(value:String) { state=state.copy(status=value) }
    suspend fun sync() {
        if(syncing) return
        syncing=true
        state=state.copy(syncActive=true)
        try {
            val available=HealthSync.available(app)
            val granted=if(available) HealthSync.client(app).permissionController.getGrantedPermissions() else emptySet()
            val basic=HealthSync.basicPermissions.count{it in granted}
            var count=0
            if(basic>0) count=withContext(Dispatchers.IO){ HealthSync.pull(app) }
            val last=if(basic>0) DateTimeFormatter.ofPattern("dd MMM, HH:mm",Locale.ENGLISH).withZone(java.time.ZoneId.systemDefault()).format(Instant.now()) else "Never"
            state=state.copy(hcAvailable=available,permissionsGranted=basic,
                backgroundAllowed=androidx.health.connect.client.permission.HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND in granted,
                lastSync=if(basic>0)last else state.lastSync,
                status=when {
                    !available->"Health Connect is not available • manual tracking works"
                    basic==0->"Connect your phone to start automatic tracking"
                    count==0->"Connected • no new phone measurements found"
                    else->"Synced $count days from your phone"
                })
            reload()
        } catch(e:Exception) {
            state=state.copy(status="Sync issue: ${e.message?.take(90)}")
            reload()
        } finally { syncing=false;state=state.copy(syncActive=false) }
    }
    suspend fun saveBody(v:Body) {try{withContext(Dispatchers.IO){Store(app).use{it.putBody(v)}};reload("Body measurement saved") }catch(e:Exception){message("Please check date and measurements")}}
    suspend fun saveJournal(v:Journal) {try{withContext(Dispatchers.IO){Store(app).use{it.putJournal(v)}};reload("Check-in saved") }catch(e:Exception){message("Please check your date")}}
    suspend fun deleteBody(date:String) {withContext(Dispatchers.IO){Store(app).use{it.deleteBody(date)}};reload("Measurement deleted")}
    suspend fun deleteJournal(date:String) {withContext(Dispatchers.IO){Store(app).use{it.deleteJournal(date)}};reload("Check-in deleted")}
}

@Composable fun HealthTheme(content:@Composable ()->Unit) {
    MaterialTheme(colorScheme=lightColorScheme(primary=Mint,onPrimary=Color.White,
        background=CanvasBg,surface=Color.White,onSurface=Ink,outline=Line), content=content)
}

@Composable fun HealthApp(
    state:UiState,onGrant:()->Unit,onSync:()->Unit,
    onBody:(Body)->Unit,onDeleteBody:(String)->Unit,
    onJournal:(Journal)->Unit,onDeleteJournal:(String)->Unit,
    onImport:()->Unit,onExport:()->Unit
) {
    var tab by rememberSaveable{mutableIntStateOf(0)}
    val names=listOf("Today","Trends","Body","Journal","Settings")
    val icons=listOf(Icons.Filled.Home,Icons.Filled.ShowChart,Icons.Filled.AccessibilityNew,Icons.Filled.EditNote,Icons.Filled.Settings)
    Scaffold(containerColor=CanvasBg,bottomBar={
        NavigationBar(containerColor=Color.White) {
            names.forEachIndexed { index,name ->
                NavigationBarItem(selected=tab==index,onClick={tab=index},icon={Icon(icons[index],contentDescription=name)},label={Text(name,fontSize=10.sp)},alwaysShowLabel=true)
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(horizontal=18.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Filled.Favorite,contentDescription=null,tint=Mint,modifier=Modifier.size(25.dp))
                Spacer(Modifier.width(9.dp))
                Text("HealthIQ",fontWeight=FontWeight.ExtraBold,fontSize=23.sp,color=Ink)
                Text("  AI",fontWeight=FontWeight.SemiBold,color=Mint,fontSize=16.sp)
                Spacer(Modifier.weight(1f))
                if(state.syncActive) CircularProgressIndicator(modifier=Modifier.size(18.dp),strokeWidth=2.dp)
                else IconButton(onClick=onSync,modifier=Modifier.size(36.dp)) {Icon(Icons.Filled.Sync,contentDescription="Sync now",tint=Mint)}
            }
            when(tab) {
                0->TodayScreen(state,onGrant,onSync)
                1->TrendScreen(state)
                2->BodyScreen(state.bodies,state.bodyMetrics,onBody,onDeleteBody)
                3->JournalScreen(state.journals,onJournal,onDeleteJournal)
                else->SettingsScreen(state,onGrant,onSync,onImport,onExport)
            }
        }
    }
}

@Composable private fun SectionHeader(title:String,subtitle:String?=null) {
    Column(Modifier.fillMaxWidth().padding(top=20.dp,bottom=10.dp)) {
        Text(title,color=Ink,fontWeight=FontWeight.Bold,fontSize=20.sp)
        if(subtitle!=null) Text(subtitle,color=Subtle,fontSize=13.sp)
    }
}
@Composable private fun Panel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Surface(modifier=modifier,border=androidx.compose.foundation.BorderStroke(1.dp,Line),shape=RoundedCornerShape(20.dp),color=Color.White,shadowElevation=0.dp) {
        Column(Modifier.padding(16.dp),content=content)
    }
}
@Composable private fun StatCard(title:String,value:String,detail:String,accent:Color,modifier:Modifier=Modifier) {
    Panel(modifier) {
        Box(Modifier.size(8.dp).background(accent,RoundedCornerShape(4.dp)))
        Spacer(Modifier.height(13.dp))
        Text(value,fontSize=27.sp,fontWeight=FontWeight.ExtraBold,color=Ink,maxLines=1)
        Text(title,fontSize=13.sp,fontWeight=FontWeight.SemiBold,color=Ink)
        Text(detail,fontSize=11.sp,color=Subtle,maxLines=2)
    }
}
private fun formatNumber(n:Number?)=if(n==null) "—" else "%,d".format(Locale.ENGLISH,n.toLong())
private fun format1(n:Double?)=if(n==null) "—" else "%.1f".format(Locale.ENGLISH,n)

@Composable private fun TodayScreen(state:UiState,onGrant:()->Unit,onSync:()->Unit) {
    val today=LocalDate.now().toString()
    val d=state.days.firstOrNull{it.date==today}
    val weight=(state.days.mapNotNull{it.weightKg?.let{n->it.date to n}} + state.bodies.mapNotNull{it.weightKg?.let{n->it.date to n}} + state.weights.map{it.date to it.kg}).maxByOrNull{it.first}?.second
    LazyColumn(contentPadding=PaddingValues(start=16.dp,end=16.dp,bottom=24.dp),verticalArrangement=Arrangement.spacedBy(0.dp)) {
        item {
            SectionHeader("Your health at a glance",LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM",Locale.ENGLISH)))
            if(state.permissionsGranted==0) {
                Panel(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment=Alignment.CenterVertically) {Icon(Icons.Filled.PhoneAndroid,null,tint=Mint); Spacer(Modifier.width(9.dp));Text("Use your phone — no wearable required",fontWeight=FontWeight.Bold)}
                    Spacer(Modifier.height(10.dp))
                    Text("Connect Health Connect to read activity and measurements already recorded by your phone and apps.",fontSize=13.sp,color=Subtle)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick=onGrant,enabled=state.hcAvailable) { Text("Connect phone data") }
                }
                Spacer(Modifier.height(12.dp))
            }
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Steps today",formatNumber(d?.steps),"Phone / Health Connect",Mint,Modifier.weight(1f))
                StatCard("Distance",d?.distanceM?.let{format1(it/1000)+" km"}?:"—","Walking & movement",Sky,Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Sleep",state.days.lastOrNull{it.sleepMinutes!=null}?.sleepMinutes?.let{format1(it/60.0)+" h"}?:"—","Last recorded night",Color(0xFF9B7DD9),Modifier.weight(1f))
                StatCard("Weight",weight?.let{format1(it)+" kg"}?:"—","Last available entry",Color(0xFFE6A345),Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                StatCard("Active energy",d?.activeKcal?.let{formatNumber(it)+" kcal"}?:"—","Recorded activity",Color(0xFFDA7B72),Modifier.weight(1f))
                StatCard("Exercise",d?.exerciseMinutes?.let{"$it min"}?:"—","Sessions today",Color(0xFF6D92C7),Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Panel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Filled.VerifiedUser,null,tint=Mint,modifier=Modifier.size(19.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(state.status,color=Subtle,fontSize=13.sp,modifier=Modifier.weight(1f))
                    IconButton(onClick=onSync,modifier=Modifier.size(34.dp)) { Icon(Icons.Filled.Refresh,"Refresh",tint=Mint) }
                }
            }
            SectionHeader("Health insights","Measured trends, not guesswork")
        }
        items(Insights.build(state.days,state.bodies,state.journals,state.weights)) { insight ->
            Panel(Modifier.fillMaxWidth().padding(bottom=10.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome,null,tint=if(insight.good==false) Color(0xFFD59243) else Mint)
                    Spacer(Modifier.width(10.dp))
                    Text(insight.title,fontWeight=FontWeight.Bold,color=Ink,fontSize=15.sp)
                }
                Spacer(Modifier.height(7.dp))
                Text(insight.description,color=Subtle,fontSize=13.sp,lineHeight=19.sp)
            }
        }
        item {Text("Informational tracking only · not medical advice or diagnosis",fontSize=11.sp,color=Subtle,modifier=Modifier.padding(top=8.dp))}
    }
}

@Composable private fun TrendScreen(state:UiState) {
    val days=state.days.filter{runCatching{LocalDate.parse(it.date)>=LocalDate.now().minusDays(29)}.getOrDefault(false)}
    val weights=(state.days.mapNotNull {it.weightKg?.let{n->it.date to n}} + state.bodies.mapNotNull {it.weightKg?.let{n->it.date to n}} + state.weights.map{it.date to it.kg}).groupBy{it.first}.mapValues{it.value.last().second}.toList().sortedBy{it.first}
    val waist=state.bodies.mapNotNull{it.waist?.let{w->it.date to w}}
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {SectionHeader("Your trends","Real measurements • recent history")}
        item {TrendPanel("Daily steps","Last 30 days",days.mapNotNull {it.steps?.toDouble()?.let{n->it.date to n}},"steps",Mint)}
        item {TrendPanel("Sleep duration","Last 30 days",days.mapNotNull {it.sleepMinutes?.div(60.0)?.let{n->it.date to n}},"hours",Color(0xFF9B7DD9))}
        item {TrendPanel("Body weight","Recorded weights",weights,"kg",Sky)}
        item {TrendPanel("Waist measurements","Manually entered / MeThreeSixty",waist,"cm",Color(0xFFE6A345))}
        item {Spacer(Modifier.height(20.dp))}
    }
}
@Composable private fun TrendPanel(title:String,subtitle:String,points:List<Pair<String,Double>>,unit:String,accent:Color) {
    Panel(Modifier.fillMaxWidth()) {
        Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp,color=Ink)
        Text(subtitle,fontSize=12.sp,color=Subtle)
        Spacer(Modifier.height(18.dp))
        if(points.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(118.dp),contentAlignment=Alignment.Center) {Text("No recorded data yet",color=Subtle)}
        } else {
            Row(verticalAlignment=Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    Text("${format1(points.last().second)} $unit",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink)
                    Text("Latest • ${points.last().first}",fontSize=11.sp,color=Subtle)
                }
                if(points.size>1) {
                    val change=points.last().second-points.first().second
                    Text("${if(change>0) "+" else ""}${format1(change)}",fontSize=13.sp,color=accent,fontWeight=FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(12.dp))
            MiniChart(points.takeLast(30).map{it.second},accent,Modifier.fillMaxWidth().height(112.dp))
        }
    }
}
@Composable private fun MiniChart(values:List<Double>,color:Color,modifier:Modifier=Modifier) {
    Canvas(modifier) {
        val top=values.maxOrNull() ?: return@Canvas
        val bottom=values.minOrNull() ?: return@Canvas
        val spread=(top-bottom).takeIf {it>0.01} ?: 1.0
        val pad=9.dp.toPx()
        val width=(size.width-pad*2).coerceAtLeast(1f)
        val height=(size.height-pad*2).coerceAtLeast(1f)
        for(i in 0..3) {val y=pad+i*height/3;drawLine(Line,Offset(pad,y),Offset(pad+width,y),strokeWidth=1.dp.toPx())}
        val p=Path()
        values.forEachIndexed { index,v ->
            val x=pad+width * if(values.size<2) 0.5f else index.toFloat()/(values.size-1)
            val y=pad+height*(1.0-(v-bottom)/spread).toFloat()
            if(index==0) p.moveTo(x,y) else p.lineTo(x,y)
        }
        drawPath(p,color,style=Stroke(width=2.7.dp.toPx(),cap=StrokeCap.Round))
        val last=values.lastOrNull()?:return@Canvas
        val y=pad+height*(1.0-(last-bottom)/spread).toFloat()
        drawCircle(color,4.dp.toPx(),Offset(pad+width,y))
    }
}

@Composable private fun BodyScreen(bodies:List<Body>,metrics:List<BodyMetric>,onSave:(Body)->Unit,onDelete:(String)->Unit) {
    var editing by remember{mutableStateOf<Body?>(null)}
    var showEditor by remember{mutableStateOf(false)}
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            SectionHeader("Body measurements","Keep your MeThreeSixty scan history in one place")
            Button(onClick={editing=bodies.firstOrNull{it.date==LocalDate.now().toString()};showEditor=true},modifier=Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add,null);Spacer(Modifier.width(8.dp));Text("Add body measurements")
            }
        }
        if(bodies.isEmpty()) item {Panel(Modifier.fillMaxWidth()) {Text("No body scans added yet",fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text("Open a MeThreeSixty scan, then enter the measurements here. Direct scan retrieval isn't available.",color=Subtle,fontSize=13.sp)}}
        items(bodies.asReversed(),key={it.date}) { r ->
            Panel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.date,fontWeight=FontWeight.Bold,fontSize=16.sp)
                        Text(r.source,color=Subtle,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                    }
                    IconButton(onClick={editing=r;showEditor=true}){Icon(Icons.Filled.Edit,"Edit",tint=Mint)}
                    IconButton(onClick={onDelete(r.date)}){Icon(Icons.Filled.DeleteOutline,"Delete",tint=Subtle)}
                }
                HorizontalDivider(color=Line)
                Spacer(Modifier.height(10.dp))
                Text(listOfNotNull(r.waist?.let{"Waist ${format1(it)} cm"},r.chest?.let{"Chest ${format1(it)} cm"},r.hips?.let{"Hips ${format1(it)} cm"},r.weightKg?.let{"Weight ${format1(it)} kg"}).joinToString("  ·  ").ifBlank{"No measurements entered"},fontSize=13.sp,color=Ink)
                val details=metrics.filter{it.date==r.date}
                if(details.isNotEmpty()) {
                    Spacer(Modifier.height(9.dp))
                    HorizontalDivider(color=Line)
                    Spacer(Modifier.height(7.dp))
                    Text("Scan measurements (${details.size})",fontSize=13.sp,fontWeight=FontWeight.Bold,color=Mint)
                    details.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            pair.forEach { m ->
                                Column(Modifier.weight(1f)) {
                                    Text(m.metric.replace('_',' ').replaceFirstChar{it.uppercase()},fontSize=11.sp,color=Subtle)
                                    Text("${format1(m.value)} ${if(m.unit=="index") "" else m.unit}",fontSize=14.sp,fontWeight=FontWeight.SemiBold,color=Ink)
                                }
                            }
                            if(pair.size==1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
                if(r.note.isNotBlank()) Text(r.note,fontSize=12.sp,color=Subtle)
            }
        }
    }
    if(showEditor) BodyEditor(editing,onDismiss={showEditor=false},onSave={onSave(it);showEditor=false})
}

@Composable private fun BodyEditor(old:Body?,onDismiss:()->Unit,onSave:(Body)->Unit) {
    var date by remember(old){mutableStateOf(old?.date?:LocalDate.now().toString())}
    var waist by remember(old){mutableStateOf(old?.waist?.toString()?:"")}
    var chest by remember(old){mutableStateOf(old?.chest?.toString()?:"")}
    var hips by remember(old){mutableStateOf(old?.hips?.toString()?:"")}
    var neck by remember(old){mutableStateOf(old?.neck?.toString()?:"")}
    var thigh by remember(old){mutableStateOf(old?.thigh?.toString()?:"")}
    var arm by remember(old){mutableStateOf(old?.arm?.toString()?:"")}
    var weight by remember(old){mutableStateOf(old?.weightKg?.toString()?:"")}
    var notes by remember(old){mutableStateOf(old?.note?:"")}
    var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Body scan / measurements")},text={
        Column(Modifier.heightIn(max=440.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)) {
            Text("Copy the numbers from MeThreeSixty. No scan photos are uploaded.",fontSize=12.sp,color=Subtle)
            Field("Date (YYYY-MM-DD)",date){date=it}
            Field("Waist / stomach (cm)",waist){waist=it}
            Field("Chest (cm)",chest){chest=it}
            Field("Hips (cm)",hips){hips=it}
            Field("Neck (cm)",neck){neck=it}
            Field("Thigh (cm)",thigh){thigh=it}
            Field("Upper arm (cm)",arm){arm=it}
            Field("Weight (kg, optional)",weight){weight=it}
            Field("Notes",notes){notes=it}
            if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
        }
    },confirmButton={TextButton(onClick={
        fun parse(v:String):Double?=if(v.isBlank())null else v.replace(',','.').toDoubleOrNull()
        val validDate=runCatching{LocalDate.parse(date)<=LocalDate.now()}.getOrDefault(false)
        val measurements=listOf(waist,chest,hips,neck,thigh,arm,weight)
        val parsed=measurements.map(::parse)
        if(!validDate || parsed.zip(measurements).any{(n,t)-> t.isNotBlank() && (n==null || n !in 10.0..350.0)} || parsed.all{it==null}) {
            error="Enter a valid date and at least one measurement (10–350)."
        } else {
            onSave(Body(date,parsed[0],parsed[1],parsed[2],parsed[3],parsed[4],parsed[5],parsed[6],old?.source?:"MeThreeSixty (manual entry)",notes))
        }
    }){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable private fun Field(label:String,value:String,onChange:(String)->Unit) {
    OutlinedTextField(value,onValueChange=onChange,label={Text(label,fontSize=12.sp)},singleLine=true,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp))
}

@Composable private fun JournalScreen(entries:List<Journal>,onSave:(Journal)->Unit,onDelete:(String)->Unit) {
    var editing by remember{mutableStateOf<Journal?>(null)}
    var show by remember{mutableStateOf(false)}
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            SectionHeader("Daily check-in","How you feel is part of the picture")
            Button(onClick={editing=entries.lastOrNull{it.date==LocalDate.now().toString()};show=true},modifier=Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add,null); Spacer(Modifier.width(8.dp));Text("Log today's wellbeing")
            }
        }
        if(entries.isEmpty()) item {Panel(Modifier.fillMaxWidth()) {Text("Your journal is empty",fontWeight=FontWeight.Bold);Text("Log mood, energy, stress, fasting, sleep, and water intake.",color=Subtle,fontSize=13.sp)}}
        items(entries.asReversed(),key={it.date}) { r ->
            Panel(Modifier.fillMaxWidth()) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text(r.date,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                    IconButton(onClick={editing=r;show=true}) {Icon(Icons.Filled.Edit,"Edit",tint=Mint)}
                    IconButton(onClick={onDelete(r.date)}) {Icon(Icons.Filled.DeleteOutline,"Delete",tint=Subtle)}
                }
                Text("Mood ${r.mood}/5   ·   Energy ${r.energy}/5   ·   Stress ${r.stress}/5",fontSize=13.sp,color=Ink)
                val extra=listOfNotNull(r.fastingHours?.let{"Fast ${format1(it)} h"},r.sleepHours?.let{"Sleep ${format1(it)} h"},r.waterLitres?.let{"Water ${format1(it)} L"})
                if(extra.isNotEmpty()) Text(extra.joinToString("  ·  "),color=Subtle,fontSize=12.sp)
                if(r.note.isNotBlank()) Text(r.note,color=Subtle,fontSize=12.sp)
            }
        }
    }
    if(show) JournalEditor(editing,onDismiss={show=false},onSave={onSave(it);show=false})
}
@Composable private fun Rating(label:String,value:Int,onChange:(Int)->Unit) {
    Column {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Text(label,fontWeight=FontWeight.SemiBold,fontSize=13.sp,modifier=Modifier.weight(1f))
            Text("$value / 5",color=Mint,fontWeight=FontWeight.Bold)
        }
        Slider(value=value.toFloat(),onValueChange={onChange(it.toInt().coerceIn(1,5))},valueRange=1f..5f,steps=3)
    }
}
@Composable private fun JournalEditor(old:Journal?,onDismiss:()->Unit,onSave:(Journal)->Unit) {
    var date by remember(old){mutableStateOf(old?.date?:LocalDate.now().toString())}
    var mood by remember(old){mutableIntStateOf(old?.mood?:3)}
    var energy by remember(old){mutableIntStateOf(old?.energy?:3)}
    var stress by remember(old){mutableIntStateOf(old?.stress?:3)}
    var fast by remember(old){mutableStateOf(old?.fastingHours?.toString()?:"")}
    var sleep by remember(old){mutableStateOf(old?.sleepHours?.toString()?:"")}
    var water by remember(old){mutableStateOf(old?.waterLitres?.toString()?:"")}
    var note by remember(old){mutableStateOf(old?.note?:"")}
    var error by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("Daily wellbeing")},text={
        Column(Modifier.heightIn(max=490.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Field("Date (YYYY-MM-DD)",date){date=it}
            Rating("Mood",mood){mood=it}; Rating("Energy",energy){energy=it}; Rating("Stress",stress){stress=it}
            Field("Fasting hours (optional)",fast){fast=it}
            Field("Sleep hours (optional)",sleep){sleep=it}
            Field("Water litres (optional)",water){water=it}
            Field("Notes",note){note=it}
            if(error.isNotEmpty()) Text(error,color=MaterialTheme.colorScheme.error,fontSize=12.sp)
        }
    },confirmButton={TextButton(onClick={
        fun n(s:String)=if(s.isBlank())null else s.replace(',','.').toDoubleOrNull()
        if(!runCatching{LocalDate.parse(date)<=LocalDate.now()}.getOrDefault(false) ||
            listOf(fast,sleep,water).any{it.isNotBlank() && (n(it)==null || n(it)!! !in 0.0..24.0)}) {
            error="Check date and numeric values (0–24)."
        } else onSave(Journal(date,mood,energy,stress,n(fast),n(sleep),n(water),note))
    }){Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable private fun SettingsScreen(state:UiState,onGrant:()->Unit,onSync:()->Unit,onImport:()->Unit,onExport:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=8.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {SectionHeader("Data & privacy","Your phone is the source of truth")}
        item {Panel(Modifier.fillMaxWidth()) {
            Text("Health Connect",fontSize=17.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("Status: ${if(state.hcAvailable) "Available" else "Unavailable"}",color=Subtle,fontSize=13.sp)
            Text("Permissions: ${state.permissionsGranted} / ${HealthSync.basicPermissions.size}",color=Subtle,fontSize=13.sp)
            Text("Background access: ${if(state.backgroundAllowed) "Allowed" else "Not granted"}",color=Subtle,fontSize=13.sp)
            Text("Last foreground sync: ${state.lastSync}",color=Subtle,fontSize=13.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick=onGrant,modifier=Modifier.fillMaxWidth(),enabled=state.hcAvailable) {Text("Manage Health Connect access")}
            OutlinedButton(onClick=onSync,modifier=Modifier.fillMaxWidth()) {Text("Refresh now")}
            Text("Automatic: refresh on app opening; background sync requested every ~6 hours (Android may delay it). Background data access requires permission.",color=Subtle,fontSize=12.sp,lineHeight=17.sp)
        }}
        item {Panel(Modifier.fillMaxWidth()) {
            Text("Import health CSV",fontSize=17.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Import Weight Trend, MeThreeSixty screenshot measurements, or a HealthIQ CSV backup. Existing scan dates are merged without discarding manually entered fields.",color=Subtle,fontSize=13.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick=onImport,modifier=Modifier.fillMaxWidth()) {Icon(Icons.Filled.FileUpload,null);Spacer(Modifier.width(8.dp));Text("Import CSV file")}
        }}
        item {Panel(Modifier.fillMaxWidth()) {
            Text("Local backup",fontSize=17.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Export health history, body measurements, and journal entries to one CSV file.",color=Subtle,fontSize=13.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick=onExport,modifier=Modifier.fillMaxWidth()) {Icon(Icons.Filled.SaveAlt,null);Spacer(Modifier.width(8.dp));Text("Export CSV backup")}
        }}
        item {Panel(Modifier.fillMaxWidth()) {
            Text("Privacy & accuracy",fontSize=17.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("No user account, ads, trackers, server calls or cloud AI. The current 'AI insights' are transparent on-device trend rules, not generative AI. No diagnoses or medical advice.",color=Subtle,fontSize=13.sp,lineHeight=19.sp)
            Spacer(Modifier.height(8.dp))
            Text("MeThreeSixty has no direct supported sync; use a converted screenshot CSV or enter values manually. The CSV import stays on this phone.",color=Subtle,fontSize=13.sp,lineHeight=19.sp)
        }}
    }
}
@Composable private fun PrivacyScreen() {
    Column(Modifier.fillMaxSize().background(CanvasBg).padding(24.dp).verticalScroll(rememberScrollState())) {
        SectionHeader("HealthIQ data permissions", "Why we request Health Connect data")
        Panel(Modifier.fillMaxWidth()) {
            Text("HealthIQ reads your steps, walking distance, active calories, exercise sessions, recorded sleep and weight to display charts and calculate trends. Only the types you grant are accessible.",fontSize=15.sp,lineHeight=22.sp)
            Spacer(Modifier.height(12.dp))
            Text("Optional permissions let the app refresh in the background and read older history. All health data is stored locally in app-private storage. There is no server or AI API.",fontSize=15.sp,lineHeight=22.sp)
            Spacer(Modifier.height(12.dp))
            Text("You can revoke access at any time under Android Settings → Health Connect → App permissions. Uninstalling the app deletes its local data unless you exported a CSV backup.",fontSize=15.sp,lineHeight=22.sp)
        }
    }
}
