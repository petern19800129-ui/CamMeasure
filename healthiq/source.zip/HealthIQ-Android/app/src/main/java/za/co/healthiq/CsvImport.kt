package za.co.healthiq

import java.time.LocalDate
import java.util.Locale

/** Local-only CSV readers. MeThreeSixty rows are transcribed from a screenshot; no app API is accessed. */
object CsvImport {
    data class Batch(
        val weights: List<Pair<String, Double>> = emptyList(),
        val metrics: List<BodyMetric> = emptyList(),
        val bodies: List<Body> = emptyList(),
        val days: List<Daily> = emptyList(),
        val journals: List<Journal> = emptyList()
    ) {
        val count get() = weights.size + metrics.size + bodies.size + days.size + journals.size
    }

    /** Supports Weight Trend v6 semicolon exports and ordinary date,weight CSV. */
    fun weights(content: String): List<Pair<String, Double>> {
        val lines=content.lineSequence().filter{it.isNotBlank()}.toList()
        val delimiter=if(lines.any{it.contains(";weight;")}) ';' else ','
        val headerIndex=lines.indexOfFirst {
            val s=it.trim().removePrefix("#").lowercase(Locale.ROOT)
            s.contains("date") && s.contains("weight")
        }
        if(headerIndex<0) throw IllegalArgumentException("Missing date/weight header")
        val header=lines[headerIndex].trim().removePrefix("#").split(delimiter).map{it.trim().lowercase(Locale.ROOT)}
        val dateColumn=header.indexOfFirst {it.contains("date")}
        val weightColumn=header.indexOfFirst{it=="weight" || it=="weight (kg)" || it=="weight_kg"}
        if(dateColumn<0 || weightColumn<0) throw IllegalArgumentException("Missing date/weight columns")
        val readings=linkedMapOf<String,Double>()
        lines.drop(headerIndex+1).forEach { line ->
            val fields=line.split(delimiter)
            if(fields.size>maxOf(dateColumn,weightColumn)) {
                val date=fields[dateColumn].trim().trim('"').take(10)
                val kg=fields[weightColumn].trim().trim('"').replace(',','.').toDoubleOrNull()
                if(kg!=null && kg in 15.0..350.0 && validDate(date)) readings[date]=kg
            }
        }
        return readings.toList()
    }

    fun read(content: String): Batch {
        val lines=content.lineSequence().filter { it.isNotBlank() }.toList()
        if(lines.isEmpty()) throw IllegalArgumentException("CSV is empty")
        val head=csvRow(lines.first()).map{it.trim().lowercase(Locale.ROOT).removePrefix("\uFEFF")}
        return when {
            head.take(4)==listOf("date","metric","value","unit") -> metricCsv(lines)
            head.take(2)==listOf("type","date") -> backupCsv(lines)
            else -> Batch(weights=weights(content))
        }
    }

    private fun metricCsv(lines:List<String>):Batch {
        val header=csvRow(lines.first()).map{it.trim().lowercase(Locale.ROOT).removePrefix("\uFEFF")}
        fun value(fields:List<String>,key:String):String = fields.getOrNull(header.indexOf(key))?.trim().orEmpty()
        val mapped=linkedMapOf<Pair<String,String>,BodyMetric>()
        lines.drop(1).forEach { line ->
            val fields=csvRow(line)
            val date=value(fields,"date").take(10)
            val metric=value(fields,"metric").lowercase(Locale.ROOT)
            val unit=value(fields,"unit")
            val number=value(fields,"value").replace(',','.').toDoubleOrNull()
            val source=value(fields,"source").ifBlank { "MeThreeSixty screenshot" }
            if(!validDate(date)) throw IllegalArgumentException("Invalid date: $date")
            if(!metric.matches(Regex("[a-z][a-z0-9_]{1,60}"))) throw IllegalArgumentException("Invalid metric: $metric")
            if(number==null || !number.isFinite() || number<0 || number>500) throw IllegalArgumentException("Invalid value for $metric")
            if(unit !in setOf("cm","kg","%","index")) throw IllegalArgumentException("Invalid unit for $metric")
            mapped[date to metric]=BodyMetric(date,metric,number,unit,source)
        }
        if(mapped.isEmpty()) throw IllegalArgumentException("No valid measurements found")
        val bodies=mapped.values.groupBy{it.date}.map { (date,items) ->
            fun m(key:String)=items.firstOrNull { it.metric==key }?.value
            Body(date=date, waist=m("waist"), chest=m("chest"), weightKg=m("weight"),
                source=items.first().source, note="Imported scan • separate left/right measurements below")
        }
        return Batch(metrics=mapped.values.toList(),bodies=bodies)
    }

    /** Accept HealthIQ's own CSV export for recovery before an APK reinstall. */
    private fun backupCsv(lines:List<String>):Batch {
        val header=csvRow(lines.first()).map{it.trim().lowercase(Locale.ROOT).removePrefix("\uFEFF")}
        fun get(fields:List<String>,key:String):String = fields.getOrNull(header.indexOf(key))?.trim().orEmpty()
        fun num(fields:List<String>,key:String):Double?=get(fields,key).toDoubleOrNull()
        fun long(fields:List<String>,key:String):Long?=get(fields,key).toLongOrNull()
        val weights=linkedMapOf<String,Double>()
        val bodies=linkedMapOf<String,Body>()
        val days=linkedMapOf<String,Daily>()
        val journals=linkedMapOf<String,Journal>()
        val metrics=linkedMapOf<Pair<String,String>,BodyMetric>()
        lines.drop(1).forEach { line ->
            val f=csvRow(line);val date=get(f,"date").take(10)
            if(!validDate(date)) return@forEach
            when(get(f,"type")) {
                "health" -> days[date]=Daily(date,long(f,"steps"),num(f,"distance_m"),num(f,"active_kcal"),long(f,"sleep_minutes"),num(f,"weight_kg"),long(f,"exercise_minutes"))
                "body" -> bodies[date]=Body(date,num(f,"waist_cm"),num(f,"chest_cm"),num(f,"hips_cm"),num(f,"neck_cm"),num(f,"thigh_cm"),num(f,"arm_cm"),num(f,"weight_kg"),get(f,"source"),get(f,"notes"))
                "journal" -> journals[date]=Journal(date,get(f,"mood").toIntOrNull()?:3,get(f,"energy").toIntOrNull()?:3,get(f,"stress").toIntOrNull()?:3,num(f,"fasting_hours"),num(f,"sleep_hours"),num(f,"water_litres"),get(f,"notes"))
                "weight_import" -> num(f,"weight_kg")?.takeIf{it in 15.0..350.0}?.let{ weights[date]=it }
                "body_metric" -> {
                    val key=get(f,"metric_key");val n=num(f,"metric_value");val u=get(f,"metric_unit")
                    if(key.isNotBlank() && n!=null && u.isNotBlank()) metrics[date to key]=BodyMetric(date,key,n,u,get(f,"source"))
                }
            }
        }
        val batch=Batch(weights.toList(),metrics.values.toList(),bodies.values.toList(),days.values.toList(),journals.values.toList())
        if(batch.count==0) throw IllegalArgumentException("No importable HealthIQ records found")
        return batch
    }

    private fun validDate(value:String)=runCatching {LocalDate.parse(value)<=LocalDate.now()}.getOrDefault(false)

    /** Minimal RFC 4180 CSV row reader, including quoted commas and escaped double-quotes. */
    private fun csvRow(line:String):List<String> {
        val values=mutableListOf<String>();val curr=StringBuilder();var quoted=false;var i=0
        while(i<line.length) {
            val ch=line[i]
            if(ch=='"') {
                if(quoted && i+1<line.length && line[i+1]=='"'){curr.append('"');i++}
                else quoted=!quoted
            } else if(ch==',' && !quoted) {values+=curr.toString();curr.setLength(0)}
            else curr.append(ch)
            i++
        }
        values+=curr.toString()
        return values
    }
}
