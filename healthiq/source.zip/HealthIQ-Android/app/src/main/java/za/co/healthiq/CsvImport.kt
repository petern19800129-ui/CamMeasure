package za.co.healthiq

import java.time.LocalDate
import java.util.Locale

object CsvImport {
    /** Supports Weight Trend v6 semicolon exports and ordinary date,weight CSV. */
    fun weights(content: String): List<Pair<String, Double>> {
        val lines=content.lineSequence().filter{it.isNotBlank()}.toList()
        val delimiter=if(lines.any{it.contains(";weight;")}) ';' else ','
        val headerIndex=lines.indexOfFirst {
            val s=it.trim().removePrefix("#").lowercase(Locale.ROOT)
            s.contains("date") && s.contains("weight")
        }
        if(headerIndex<0) throw IllegalArgumentException("Missing date/weight header")
        val header=lines[headerIndex].trim().removePrefix("#").split(delimiter).map{it.trim().lowercase(Locale.ROOT)}
        val dateColumn=header.indexOfFirst {it.contains("date")}
        val weightColumn=header.indexOfFirst{it=="weight" || it=="weight (kg)" || it=="weight_kg"}
        if(dateColumn<0 || weightColumn<0) throw IllegalArgumentException("Missing date/weight columns")
        val readings=linkedMapOf<String,Double>()
        lines.drop(headerIndex+1).forEach { line ->
            val fields=line.split(delimiter)
            if(fields.size>maxOf(dateColumn,weightColumn)) {
                val date=fields[dateColumn].trim().trim('"').take(10)
                val kg=fields[weightColumn].trim().trim('"').replace(',','.').toDoubleOrNull()
                if(kg!=null && kg in 15.0..350.0 && runCatching{LocalDate.parse(date)<=LocalDate.now()}.getOrDefault(false)) {
                    readings[date]=kg  // The last measurement per date is retained.
                }
            }
        }
        return readings.toList()
    }
}
