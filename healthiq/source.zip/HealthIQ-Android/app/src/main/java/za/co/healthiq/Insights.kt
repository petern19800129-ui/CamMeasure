package za.co.healthiq

import java.time.LocalDate
import kotlin.math.abs

data class Insight(val title:String, val description:String, val good:Boolean?=null)

/** Transparent local analytics, NOT an LLM or diagnostic AI. Every claim requires actual data. */
object Insights {
    fun build(days:List<Daily>, body:List<Body>, journal:List<Journal>, imports:List<WeightEntry> = emptyList()):List<Insight> {
        val result = mutableListOf<Insight>()
        val today = LocalDate.now()
        fun inPeriod(d:String, from:Int, to:Int):Boolean = runCatching {
            val distance = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(d),today)
            distance in from.toLong()..to.toLong()
        }.getOrDefault(false)

        val recentSteps = days.filter { inPeriod(it.date,1,7) }.mapNotNull { it.steps }
        val earlierSteps = days.filter { inPeriod(it.date,8,14) }.mapNotNull { it.steps }
        if(recentSteps.size>=4 && earlierSteps.size>=4) {
            val now = recentSteps.average()
            val old = earlierSteps.average()
            val change=(now-old)/old.coerceAtLeast(1.0)*100
            result += Insight(
                "Walking activity ${if(change>=0) "increased" else "decreased"}",
                "Your average was ${"%,.0f".format(now)} steps on ${recentSteps.size} tracked days, ${"%.0f".format(abs(change))}% ${if(change>=0) "higher" else "lower"} than the previous period (${earlierSteps.size} days).",
                change>=0
            )
        }
        val sleep = days.filter {inPeriod(it.date,1,7)}.mapNotNull{it.sleepMinutes?.toDouble()?.div(60)} +
            journal.filter {inPeriod(it.date,1,7) && days.none{day-> day.date==it.date && day.sleepMinutes!=null}}.mapNotNull{it.sleepHours}
        if(sleep.size>=3) {
            val avg=sleep.average()
            result += Insight("Sleep pattern", "Average logged sleep over ${sleep.size} nights: ${"%.1f".format(avg)} hours. Compare this with how rested you felt.", null)
        }
        val weights = (days.mapNotNull { d -> d.weightKg?.let{ d.date to it } } + body.mapNotNull { b -> b.weightKg?.let{b.date to it} } + imports.map{it.date to it.kg})
            .groupBy {it.first}.mapValues { (_,readings)->readings.last().second }
        val recentWeights = weights.filterKeys {inPeriod(it,1,7)}.values
        val earlierWeights = weights.filterKeys {inPeriod(it,8,14)}.values
        if(recentWeights.size>=3 && earlierWeights.size>=3) {
            val diff=recentWeights.average()-earlierWeights.average()
            result += Insight("Weight trend", "The recent recorded average is ${"%.1f".format(recentWeights.average())} kg, ${if(diff>=0) "+" else ""}${"%.1f".format(diff)} kg compared with the preceding period. Daily weight can fluctuate with hydration.", null)
        }
        val waist=body.filter{it.waist!=null}.sortedBy{it.date}
        if(waist.size>=2) {
            val a=waist[waist.size-2]
            val b=waist.last()
            val diff=b.waist!!-a.waist!!
            result+=Insight("Body scan measurements", "Waist is ${"%.1f".format(b.waist)} cm (${if(diff>=0) "+" else ""}${"%.1f".format(diff)} cm since ${a.date}). Changes may reflect measurement position and scan conditions.",if(diff==0.0)null else diff<0)
        }
        val recentMood=journal.filter{inPeriod(it.date,1,7)}
        if(recentMood.size>=4) {
            result+=Insight("Energy check-in", "Your logged energy averages ${"%.1f".format(recentMood.map{it.energy}.average())}/5 across ${recentMood.size} days. Mood and energy are subjective, not medical measurements.",null)
        }
        if(result.isEmpty()) {
            result += Insight("Building your baseline", "No trends yet. Connect Health Connect or add a few days of body measurements and check-ins. Insights appear only when there is enough real data.")
        }
        result += Insight("Privacy first", "These insights are calculated on your phone. No health data is uploaded or sent to an AI service.")
        return result
    }
}
