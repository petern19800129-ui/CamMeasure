package za.co.healthiq

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.HealthConnectFeatures
import androidx.health.connect.client.aggregate.AggregateMetric
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.Duration
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.TimeUnit

object HealthSync {
    val basicPermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class)
    )

    fun available(context: Context): Boolean =
        HealthConnectClient.getSdkStatus(context) == HealthConnectClient.SDK_AVAILABLE

    fun client(context: Context): HealthConnectClient = HealthConnectClient.getOrCreate(context)

    fun backgroundFeature(client: HealthConnectClient):Boolean =
        client.features.getFeatureStatus(HealthConnectFeatures.FEATURE_READ_HEALTH_DATA_IN_BACKGROUND) == HealthConnectFeatures.FEATURE_STATUS_AVAILABLE

    fun historyFeature(client: HealthConnectClient):Boolean =
        client.features.getFeatureStatus(HealthConnectFeatures.FEATURE_READ_HEALTH_DATA_HISTORY) == HealthConnectFeatures.FEATURE_STATUS_AVAILABLE

    fun requestPermissions(context: Context):Set<String> {
        if(!available(context)) return emptySet()
        val client = client(context)
        return basicPermissions + buildSet {
            if(backgroundFeature(client)) add(HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND)
            if(historyFeature(client)) add(HealthPermission.PERMISSION_READ_HEALTH_DATA_HISTORY)
        }
    }

    fun schedule(context: Context) {
        val work = PeriodicWorkRequestBuilder<HealthSyncWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "healthiq-health-connect", ExistingPeriodicWorkPolicy.KEEP, work
        )
    }

    /** Reads only types for which the user granted permission. No external server or network. */
    suspend fun pull(context: Context, days: Long = 14): Int {
        if(!available(context)) return 0
        val hc = client(context)
        val granted = hc.permissionController.getGrantedPermissions()
        if(basicPermissions.none { it in granted }) return 0
        val store = Store(context)
        val zone = ZoneId.systemDefault()
        val first = LocalDate.now().minusDays(days - 1)
        val lastExclusive = LocalDate.now().plusDays(1)
        val start = first.atStartOfDay(zone).toInstant()
        val end = lastExclusive.atStartOfDay(zone).toInstant()
        val allWeights = mutableMapOf<String, Pair<Long, Double>>()
        val allSleep = mutableMapOf<String, Long>()
        val allExercise = mutableMapOf<String, Long>()

        if(HealthPermission.getReadPermission(WeightRecord::class) in granted) {
            runCatching {
                var next: String? = null
                do {
                    val response = hc.readRecords(ReadRecordsRequest(
                        recordType = WeightRecord::class,
                        timeRangeFilter = TimeRangeFilter.between(start, end),
                        pageSize = 500,
                        pageToken = next
                    ))
                    response.records.forEach { r ->
                        val date = r.time.atZone(zone).toLocalDate().toString()
                        val old = allWeights[date]
                        if(old == null || r.time.toEpochMilli() > old.first)
                            allWeights[date] = r.time.toEpochMilli() to r.weight.inKilograms
                    }
                    next = response.pageToken
                } while(next != null)
            }
        }
        if(HealthPermission.getReadPermission(SleepSessionRecord::class) in granted) {
            runCatching {
                var next: String? = null
                do {
                    val response = hc.readRecords(ReadRecordsRequest(
                        recordType = SleepSessionRecord::class,
                        // Include sleeps that started the evening before our first date.
                        timeRangeFilter = TimeRangeFilter.between(start.minus(Duration.ofHours(18)), end),
                        pageSize = 500,
                        pageToken = next
                    ))
                    response.records.forEach { r ->
                        val date = r.endTime.atZone(zone).toLocalDate().toString()
                        if(date >= first.toString() && date < lastExclusive.toString()) {
                            val minutes = Duration.between(r.startTime, r.endTime).toMinutes().coerceAtLeast(0)
                            allSleep[date] = (allSleep[date] ?: 0L) + minutes
                        }
                    }
                    next = response.pageToken
                } while(next != null)
            }
        }
        if(HealthPermission.getReadPermission(ExerciseSessionRecord::class) in granted) {
            runCatching {
                var next: String? = null
                do {
                    val response = hc.readRecords(ReadRecordsRequest(
                        recordType = ExerciseSessionRecord::class,
                        timeRangeFilter = TimeRangeFilter.between(start, end),
                        pageSize = 500, pageToken = next
                    ))
                    response.records.forEach { r ->
                        val date = r.endTime.atZone(zone).toLocalDate().toString()
                        if(date >= first.toString() && date < lastExclusive.toString()) {
                            val minutes = Duration.between(r.startTime,r.endTime).toMinutes().coerceAtLeast(0)
                            allExercise[date] = (allExercise[date] ?: 0L) + minutes
                        }
                    }
                    next = response.pageToken
                } while(next != null)
            }
        }

        var saved = 0
        for(offset in days-1 downTo 0) {
            val date = LocalDate.now().minusDays(offset)
            val from = date.atStartOfDay(zone).toInstant()
            val to = date.plusDays(1).atStartOfDay(zone).toInstant()
            val metrics = buildSet<AggregateMetric<*>> {
                if(HealthPermission.getReadPermission(StepsRecord::class) in granted) add(StepsRecord.COUNT_TOTAL)
                if(HealthPermission.getReadPermission(DistanceRecord::class) in granted) add(DistanceRecord.DISTANCE_TOTAL)
                if(HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class) in granted) add(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)
            }
            val aggregation = if(metrics.isNotEmpty()) runCatching {
                hc.aggregate(AggregateRequest(metrics, TimeRangeFilter.between(from,to)))
            }.getOrNull() else null
            val key = date.toString()
            val day = Daily(
                date=key,
                steps=aggregation?.get(StepsRecord.COUNT_TOTAL),
                distanceM=aggregation?.get(DistanceRecord.DISTANCE_TOTAL)?.inMeters,
                activeKcal=aggregation?.get(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL)?.inKilocalories,
                sleepMinutes=allSleep[key],
                weightKg=allWeights[key]?.second,
                exerciseMinutes=allExercise[key]
            )
            // Avoid confusing an absence of access/data with a zero reading.
            if(listOf(day.steps,day.distanceM,day.activeKcal,day.sleepMinutes,day.weightKg,day.exerciseMinutes).any {it != null}) {
                store.putDaily(day)
                saved++
            }
        }
        store.close()
        return saved
    }
}

class HealthSyncWorker(context: Context, params: WorkerParameters): CoroutineWorker(context,params) {
    override suspend fun doWork(): Result {
        if(!HealthSync.available(applicationContext)) return Result.success()
        return try {
            val hc = HealthSync.client(applicationContext)
            if(HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND in hc.permissionController.getGrantedPermissions()) {
                HealthSync.pull(applicationContext, 14)
            }
            Result.success()
        } catch (_: SecurityException) {
            Result.success()  // User can revoke permissions at any time.
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
