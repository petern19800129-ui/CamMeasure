package za.co.healthiq

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.time.LocalDate

/** All medical-ish data stays in the phone's app-private SQLite database. */
data class Daily(
    val date: String,
    val steps: Long? = null,
    val distanceM: Double? = null,
    val activeKcal: Double? = null,
    val sleepMinutes: Long? = null,
    val weightKg: Double? = null,
    val exerciseMinutes: Long? = null
)

data class Body(
    val date: String,
    val waist: Double? = null,
    val chest: Double? = null,
    val hips: Double? = null,
    val neck: Double? = null,
    val thigh: Double? = null,
    val arm: Double? = null,
    val weightKg: Double? = null,
    val source: String = "Manual / MeThreeSixty",
    val note: String = ""
)

data class WeightEntry(val date:String, val kg:Double)

data class Journal(
    val date: String,
    val mood: Int = 3,
    val energy: Int = 3,
    val stress: Int = 3,
    val fastingHours: Double? = null,
    val sleepHours: Double? = null,
    val waterLitres: Double? = null,
    val note: String = ""
)

class Store(context: Context): SQLiteOpenHelper(context, "healthiq.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE daily (date TEXT PRIMARY KEY, steps INTEGER, distance_m REAL,
            active_kcal REAL, sleep_minutes INTEGER, weight_kg REAL, exercise_minutes INTEGER)""")
        db.execSQL("""CREATE TABLE body (date TEXT PRIMARY KEY, waist REAL, chest REAL, hips REAL,
            neck REAL, thigh REAL, arm REAL, weight_kg REAL, source TEXT, note TEXT)""")
        db.execSQL("""CREATE TABLE weight_manual (date TEXT PRIMARY KEY, weight_kg REAL NOT NULL)""")
        db.execSQL("""CREATE TABLE journal (date TEXT PRIMARY KEY, mood INTEGER, energy INTEGER,
            stress INTEGER, fasting_hours REAL, sleep_hours REAL, water_litres REAL, note TEXT)""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if(oldVersion<2) db.execSQL("CREATE TABLE IF NOT EXISTS weight_manual (date TEXT PRIMARY KEY, weight_kg REAL NOT NULL)")
    }

    fun putDaily(v: Daily) {
        val c = ContentValues().apply {
            put("date", v.date); put("steps", v.steps); put("distance_m", v.distanceM)
            put("active_kcal", v.activeKcal); put("sleep_minutes", v.sleepMinutes)
            put("weight_kg", v.weightKg); put("exercise_minutes", v.exerciseMinutes)
        }
        writableDatabase.insertWithOnConflict("daily", null, c, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun putBody(v: Body) {
        require(LocalDate.parse(v.date) <= LocalDate.now()) { "Date cannot be in the future" }
        val c = ContentValues().apply {
            put("date", v.date); put("waist", v.waist); put("chest", v.chest); put("hips", v.hips)
            put("neck", v.neck); put("thigh", v.thigh); put("arm", v.arm)
            put("weight_kg", v.weightKg); put("source", v.source); put("note", v.note)
        }
        writableDatabase.insertWithOnConflict("body", null, c, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun putJournal(v: Journal) {
        require(LocalDate.parse(v.date) <= LocalDate.now())
        val c = ContentValues().apply {
            put("date", v.date); put("mood", v.mood); put("energy", v.energy)
            put("stress", v.stress); put("fasting_hours", v.fastingHours)
            put("sleep_hours", v.sleepHours); put("water_litres", v.waterLitres); put("note", v.note)
        }
        writableDatabase.insertWithOnConflict("journal", null, c, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun allDaily(): List<Daily> {
        val result = mutableListOf<Daily>()
        readableDatabase.rawQuery("SELECT * FROM daily ORDER BY date", null).use { c ->
            fun l(s:String):Long? = c.getColumnIndexOrThrow(s).let { i -> if(c.isNull(i)) null else c.getLong(i) }
            fun d(s:String):Double? = c.getColumnIndexOrThrow(s).let { i -> if(c.isNull(i)) null else c.getDouble(i) }
            while(c.moveToNext()) result += Daily(c.getString(0),l("steps"),d("distance_m"),d("active_kcal"),l("sleep_minutes"),d("weight_kg"),l("exercise_minutes"))
        }
        return result
    }
    fun allBody(): List<Body> {
        val result = mutableListOf<Body>()
        readableDatabase.rawQuery("SELECT * FROM body ORDER BY date",null).use { c ->
            fun d(s:String):Double? = c.getColumnIndexOrThrow(s).let { i -> if(c.isNull(i)) null else c.getDouble(i) }
            fun s(n:String):String = c.getColumnIndexOrThrow(n).let { i -> if(c.isNull(i)) "" else c.getString(i) }
            while(c.moveToNext()) result += Body(s("date"),d("waist"),d("chest"),d("hips"),d("neck"),d("thigh"),d("arm"),d("weight_kg"),s("source"),s("note"))
        }
        return result
    }
    fun allJournal(): List<Journal> {
        val result = mutableListOf<Journal>()
        readableDatabase.rawQuery("SELECT * FROM journal ORDER BY date",null).use { c ->
            fun d(s:String):Double? = c.getColumnIndexOrThrow(s).let { i -> if(c.isNull(i)) null else c.getDouble(i) }
            fun s(n:String):String = c.getColumnIndexOrThrow(n).let { i -> if(c.isNull(i)) "" else c.getString(i) }
            while(c.moveToNext()) result += Journal(s("date"),c.getInt(c.getColumnIndexOrThrow("mood")),c.getInt(c.getColumnIndexOrThrow("energy")),c.getInt(c.getColumnIndexOrThrow("stress")),d("fasting_hours"),d("sleep_hours"),d("water_litres"),s("note"))
        }
        return result
    }
    fun allWeights():List<WeightEntry> {
        val result=mutableListOf<WeightEntry>()
        readableDatabase.rawQuery("SELECT date, weight_kg FROM weight_manual ORDER BY date",null).use { c ->
            while(c.moveToNext()) result+=WeightEntry(c.getString(0),c.getDouble(1))
        }
        return result
    }
    fun deleteBody(date:String) { writableDatabase.delete("body", "date=?", arrayOf(date)) }
    fun deleteJournal(date:String) { writableDatabase.delete("journal", "date=?", arrayOf(date)) }

    /** Non-destructive CSV import: changes only weight_kg for a matching date. */
    fun mergeBodyWeight(date: String, kg: Double) {
        require(kg in 15.0..350.0)
        require(LocalDate.parse(date) <= LocalDate.now())
        val row=ContentValues().apply { put("date",date);put("weight_kg",kg) }
        writableDatabase.insertWithOnConflict("weight_manual",null,row,SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun exportCsv(): String {
        fun esc(v:Any?):String = "\"" + (v?.toString() ?: "").replace("\"", "\"\"") + "\""
        val lines=mutableListOf("type,date,steps,distance_m,active_kcal,sleep_minutes,weight_kg,exercise_minutes,waist_cm,chest_cm,hips_cm,neck_cm,thigh_cm,arm_cm,mood,energy,stress,fasting_hours,sleep_hours,water_litres,source,notes")
        fun line(vararg values:Any?) { lines += values.joinToString(",", transform=::esc) }
        allDaily().forEach { line("health",it.date,it.steps,it.distanceM,it.activeKcal,it.sleepMinutes,it.weightKg,it.exerciseMinutes,null,null,null,null,null,null,null,null,null,null,null,null,null,null) }
        allBody().forEach { line("body",it.date,null,null,null,null,it.weightKg,null,it.waist,it.chest,it.hips,it.neck,it.thigh,it.arm,null,null,null,null,null,null,it.source,it.note) }
        allWeights().forEach { line("weight_import",it.date,null,null,null,null,it.kg,null,null,null,null,null,null,null,null,null,null,null,null,null,"Weight Trend CSV",null) }
        allJournal().forEach { line("journal",it.date,null,null,null,null,null,null,null,null,null,null,null,null,it.mood,it.energy,it.stress,it.fastingHours,it.sleepHours,it.waterLitres,null,it.note) }
        return lines.joinToString("\n") + "\n"
    }
}
